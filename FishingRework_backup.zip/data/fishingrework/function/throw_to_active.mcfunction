#since the only way to do scale is to use ints
#once subtracted, scale store into singles in storage
#then pass all via macro(?) to motion of entity

#extract current location into dx,dy,dz (fr_data)
execute as @s at @s run function fishingrework:util/load_d_pos
#put location of active_fisher tag int x,y,z
execute as @a[tag=active_fisher,limit=1] at @s run function fishingrework:util/load_pos
#add one block for player head target (or at least clear the floor)
scoreboard players operation $y fr_data += #2 fr_data
#subtract dx,dy,dz from x,y,z (target - location = delta pointing at target)
scoreboard players operation $x fr_data -= $dx fr_data
scoreboard players operation $y fr_data -= $dy fr_data
scoreboard players operation $z fr_data -= $dz fr_data

#adjust variable scope to avoid imprecision on further steps
#a = a*100
scoreboard players operation $x fr_data *= #1000 fr_data
scoreboard players operation $y fr_data *= #1000 fr_data
scoreboard players operation $z fr_data *= #1000 fr_data

# velocity = x * 0.1, y * 0.1 + sqrt(sqrt{x*x + y*y + z*z}]), z * 0.1
#copy to d values
scoreboard players operation $dx fr_data = $x fr_data
scoreboard players operation $dy fr_data = $y fr_data
scoreboard players operation $dz fr_data = $z fr_data
#multiply by themselves
scoreboard players operation $dx fr_data *= $dx fr_data
scoreboard players operation $dy fr_data *= $dy fr_data
scoreboard players operation $dz fr_data *= $dz fr_data
#add together
scoreboard players set $temp fr_data 0
scoreboard players operation $temp fr_data += $dx fr_data
scoreboard players operation $temp fr_data += $dy fr_data
scoreboard players operation $temp fr_data += $dz fr_data
#square root twice
# INPUT: scoreboard players set #sqrt_in fr_data <x>
# OUTPUT: scoreboard players get #sqrt_out fr_data
scoreboard players operation #sqrt_in fr_data = $temp fr_data
function fishingrework:util/sqrt
scoreboard players operation #sqrt_in fr_data = #sqrt_out fr_data
function fishingrework:util/sqrt
scoreboard players operation $temp fr_data = #sqrt_out fr_data
#need to divide the result of this by 10 to get it back to scale (since all inputs were multiplied by 1000)
scoreboard players operation $temp fr_data /= #10 fr_data

#divide x, y, and z by 10 (y is special to get slightly higher on my own tweak)
scoreboard players operation $x fr_data /= #10 fr_data
scoreboard players operation $y fr_data /= #9 fr_data
scoreboard players operation $z fr_data /= #10 fr_data

#add the extra temp to y
scoreboard players operation $y fr_data += $temp fr_data

#(if this is a mob, this needs to be multiplied by 4.6), TODO

#divide x, y, and z by 1000 by storing into temp storage, and then moving that storage into array storage "Motion"
#a = a / 1000
data modify storage fishingrework:data Motion set value []

# 2.85 max maybe to protect against entity motion cap when multiplied by 3.5 later? see if applicable

execute store result storage fishingrework:data tempint double .001 run scoreboard players get $x fr_data
data modify storage fishingrework:data Motion append from storage fishingrework:data tempint

execute store result storage fishingrework:data tempint double .001 run scoreboard players get $y fr_data
data modify storage fishingrework:data Motion append from storage fishingrework:data tempint

execute store result storage fishingrework:data tempint double .001 run scoreboard players get $z fr_data
data modify storage fishingrework:data Motion append from storage fishingrework:data tempint

data modify entity @s Motion set from storage fishingrework:data Motion

#execute as @s at @s run function fishingrework:util/mult_motion