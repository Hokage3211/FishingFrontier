#executed from a player who just used a rod

#tellraw @s "Used rod!"
scoreboard players set @s fr_data 0

#store active caster's ID for setting score to others
execute store result score $active_caster fr_data run scoreboard players get @s fisherman_id
#default to fail if no entity is found
scoreboard players set $result fr_data 0
#link ourselves to the nearest unlinked bobber with macro
execute at @s anchored eyes rotated ~ 0 positioned ^ ^ ^0.3 store result score $result fr_data as @e[type=fishing_bobber,tag=!has_owner,sort=nearest,limit=1] run function fishingrework:util/link_bobber
scoreboard players reset $active_caster fr_data

#give advancements based on luck
execute store result score $luck_temp frw_tl run attribute @s minecraft:generic.luck get
execute if score $luck_temp frw_tl matches 1.. if entity @s[advancements={fishingrework:enchantment_info/live_catch=true}] run advancement grant @s only fishingrework:enchantment_info/live_catch_progression/live_catch_t2
execute if score $luck_temp frw_tl matches 1.. if entity @s[advancements={fishingrework:enchantment_info/treasure_hunter=true}] run advancement grant @s only fishingrework:enchantment_info/treasure_hunter_progression/treasure_t2

execute if score $luck_temp frw_tl matches 2.. if entity @s[advancements={fishingrework:enchantment_info/live_catch=true}] run advancement grant @s only fishingrework:enchantment_info/live_catch_progression/live_catch_t3
execute if score $luck_temp frw_tl matches 2.. if entity @s[advancements={fishingrework:enchantment_info/treasure_hunter=true}] run advancement grant @s only fishingrework:enchantment_info/treasure_hunter_progression/treasure_t3

execute if score $luck_temp frw_tl matches 3.. if entity @s[advancements={fishingrework:enchantment_info/live_catch=true}] run advancement grant @s only fishingrework:enchantment_info/live_catch_progression/live_catch_t4
execute if score $luck_temp frw_tl matches 3.. if entity @s[advancements={fishingrework:enchantment_info/treasure_hunter=true}] run advancement grant @s only fishingrework:enchantment_info/treasure_hunter_progression/treasure_t4

execute if score $luck_temp frw_tl matches 4.. if entity @s[advancements={fishingrework:enchantment_info/live_catch=true}] run advancement grant @s only fishingrework:enchantment_info/live_catch_progression/live_catch_t5
execute if score $luck_temp frw_tl matches 4.. if entity @s[advancements={fishingrework:enchantment_info/treasure_hunter=true}] run advancement grant @s only fishingrework:enchantment_info/treasure_hunter_progression/treasure_t5

#execute if score $result fr_data matches 1.. run say bobber found!

#tag @s add has_bobber_out
