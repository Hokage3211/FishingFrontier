#excute as a bobber entity

tag @s add has_owner
#tag this bobber so the marker entity can mount it
tag @s add fishrework_working

scoreboard players operation @s fisherman_id = $active_caster fr_data
#set the fisherman tier of this item based on player data
execute store result score @s frw_tl run execute as @a if score @s fisherman_id = $active_caster fr_data run attribute @s minecraft:generic.luck get
#mount tracker marker on top of bobber
execute summon marker run function fishingrework:util/mount_marker_to_bobber

tag @s remove fishrework_working
return 1