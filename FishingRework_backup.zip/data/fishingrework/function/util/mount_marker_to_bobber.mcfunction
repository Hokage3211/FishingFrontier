#executed from a marker to mount to a bobber to keep track

tag @s add fishing_bobber_tracker
#mount the specially tagged bobber
execute at @s run ride @s mount @e[tag=fishrework_working,sort=nearest,limit=1]
scoreboard players operation @s fisherman_id = $active_caster fr_data