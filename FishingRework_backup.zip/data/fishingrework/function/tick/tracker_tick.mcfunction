scoreboard players set $result fr_data 0
scoreboard players operation $temp fr_data = @s fisherman_id

#kill if farther than 30 blocks away
execute store success score $result fr_data on vehicle if entity @s[type=fishing_bobber] at @s on origin if entity @s[distance=31..]
#if so, kill ourselves, the bobber, and lavafish tracker too
execute if score $result fr_data matches 1 run kill @s
execute if score $result fr_data matches 1 as @e[type=minecraft:fishing_bobber] if score @s fisherman_id = $temp fr_data run kill @s
execute if score $result fr_data matches 1 as @e[type=minecraft:armor_stand,tag=lava_fish_item] if score @s fisherman_id = $temp fr_data run kill @s
execute if score $result fr_data matches 1 run return 0

#if this tracker has a bobber attached to it, set a temp flag, 0 = bobber disappeared
execute as @s on vehicle run scoreboard players set $result fr_data 1

#we still are tracking the bobber
execute if score $result fr_data matches 1 run return 0

#anything past this point is when the player reels the rod in

execute at @s as @e[type=item,nbt={Age:0s,PickupDelay:0s},distance=0..0.5] run function fishingrework:util/convert_item_to_entity with entity @s Item.components.minecraft:custom_data
#execute as @a if score @s fisherman_id = $temp fr_data if predicate fishingrework:holding_fishing_rod run tellraw @s "Reeled in rod!"
kill @s
